<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class KategoriUser extends Migration
{
    public function up()
    {
        // Membuat kolom/field untuk tabel 
        $this->forge->addField([
            'id_kategori_user'          => [
                'type'           => 'INT',
                'constraint'     => 11,
                'auto_increment' => true
            ],
            'nama_kategori_user'       => [
                'type'           => 'VARCHAR',
                'constraint'     => '45'
            ]

        ]);

        // Membuat primary key
        $this->forge->addKey('id_kategori_user', TRUE);

        // Membuat tabel 
        $this->forge->createTable('kategori_user', TRUE);
    }

    //-------------------------------------------------------

    public function down()
    {
        // menghapus tabel 
        $this->forge->dropTable('kategori_user');
    }
}
