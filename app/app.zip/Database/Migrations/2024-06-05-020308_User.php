<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class User extends Migration
{
    public function up()
    {
        // Membuat kolom/field untuk tabel 
        $this->forge->addField([
            'id_user'          => [
                'type'           => 'INT',
                'constraint'     => 11,
                'auto_increment' => true
            ],
            'username'       => [
                'type'           => 'VARCHAR',
                'constraint'     => '20'
            ],
            'password'      => [
                'type'           => 'VARCHAR',
                'constraint'     => '100',

            ],
            'nama_user'      => [
                'type'           => 'VARCHAR',
                'constraint'     => '20',

            ],
            'id_kategori_user'      => [
                'type'           => 'CHAR',
                'constraint'     => '1',

            ],

        ]);

        // Membuat primary key
        $this->forge->addKey('id_user', TRUE);

        // Membuat tabel 
        $this->forge->createTable('user', TRUE);
    }

    //-------------------------------------------------------

    public function down()
    {
        // menghapus tabel 
        $this->forge->dropTable('user');
    }
}
