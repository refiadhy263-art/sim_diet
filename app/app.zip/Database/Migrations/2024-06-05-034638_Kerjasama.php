<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Kerjasama extends Migration
{
    public function up()
    {
        // Membuat kolom/field untuk tabel 
        $this->forge->addField([
            'id_kerjasama'          => [
                'type'           => 'INT',
                'constraint'     => 11,
                'auto_increment' => true
            ],
            'id_jenis'          => [
                'type'           => 'CHAR',
                'constraint'     => 1,

            ],
            'id_tingkat'          => [
                'type'           => 'CHAR',
                'constraint'     => 1,

            ],
            'judul'       => [
                'type'           => 'VARCHAR',
                'constraint'     => '100'
            ],
            'nomor'      => [
                'type'           => 'VARCHAR',
                'constraint'     => '45',

            ],
            'status'      => [
                'type'           => 'CHAR',
                'constraint'     => '1',

            ],
            'tgl_awal'      => [
                'type'           => 'CHAR',
                'constraint'     => '10',

            ],
            'tgl_akhir'      => [
                'type'           => 'CHAR',
                'constraint'     => '10',

            ],
            'deskripsi'      => [
                'type'           => 'TEXT',

            ],
            'instansi_pihak1'      => [
                'type'           => 'VARCHAR',
                'constraint'     => '100',

            ],
            'alamat_pihak1'      => [
                'type'           => 'VARCHAR',
                'constraint'     => '225',

            ],
            'pj_pihak1'      => [
                'type'           => 'VARCHAR',
                'constraint'     => '100',

            ],
            'jabatan_pihak1'      => [
                'type'           => 'VARCHAR',
                'constraint'     => '100',

            ],
            'instansi_pihak2'      => [
                'type'           => 'VARCHAR',
                'constraint'     => '100',

            ],
            'alamat_pihak2'      => [
                'type'           => 'VARCHAR',
                'constraint'     => '225',

            ],
            'pj_pihak2'      => [
                'type'           => 'VARCHAR',
                'constraint'     => '100',

            ],
            'jabatan_pihak2'      => [
                'type'           => 'VARCHAR',
                'constraint'     => '100',

            ],
            'berkas'      => [
                'type'           => 'VARCHAR',
                'constraint'     => '20',

            ],
            'tahun'      => [
                'type'           => 'CHAR',
                'constraint'     => '4',

            ],
            'tahun'      => [
                'type'           => 'CHAR',
                'constraint'     => '4',

            ],
            'created_at DATETIME DEFAULT CURRENT_TIMESTAMP',
            'id_user'      => [
                'type'           => 'CHAR',
                'constraint'     => '3',

            ],



        ]);

        // Membuat primary key
        $this->forge->addKey('id_kerjasama', TRUE);

        // Membuat tabel 
        $this->forge->createTable('kerjasama', TRUE);
    }

    //-------------------------------------------------------

    public function down()
    {
        // menghapus tabel 
        $this->forge->dropTable('kerjasama');
    }
}
