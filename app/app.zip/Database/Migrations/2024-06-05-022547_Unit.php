<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Unit extends Migration
{
    public function up()
    {
        // Membuat kolom/field untuk tabel 
        $this->forge->addField([
            'id_unit'          => [
                'type'           => 'INT',
                'constraint'     => 11,
                'auto_increment' => true
            ],
            'nama_unit'       => [
                'type'           => 'VARCHAR',
                'constraint'     => '45'
            ]

        ]);

        // Membuat primary key
        $this->forge->addKey('id_unit', TRUE);

        // Membuat tabel 
        $this->forge->createTable('unit', TRUE);
    }

    //-------------------------------------------------------

    public function down()
    {
        // menghapus tabel 
        $this->forge->dropTable('unit');
    }
}
