<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Jenis extends Migration
{
    public function up()
    {
        // Membuat kolom/field untuk tabel 
        $this->forge->addField([
            'id_jenis'          => [
                'type'           => 'INT',
                'constraint'     => 11,
                'auto_increment' => true
            ],
            'nama_jenis'       => [
                'type'           => 'VARCHAR',
                'constraint'     => '45'
            ]

        ]);

        // Membuat primary key
        $this->forge->addKey('id_jenis', TRUE);

        // Membuat tabel 
        $this->forge->createTable('jenis', TRUE);
    }

    //-------------------------------------------------------

    public function down()
    {
        // menghapus tabel 
        $this->forge->dropTable('jenis');
    }
}
