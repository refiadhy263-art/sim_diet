<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Pengaturan extends Migration
{
    public function up()
    {
        // Membuat kolom/field untuk tabel 
        $this->forge->addField([
            'id_pengaturan'          => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true
            ],
            'nama_instansi'       => [
                'type'           => 'VARCHAR',
                'constraint'     => '45'
            ],
            'id_semester'      => [
                'type'           => 'CHAR',
                'constraint'     => 5,

            ]

        ]);

        // Membuat primary key
        $this->forge->addKey('id_pengaturan', TRUE);

        // Membuat tabel 
        $this->forge->createTable('pengaturan', TRUE);
    }

    //-------------------------------------------------------

    public function down()
    {
        // menghapus tabel 
        $this->forge->dropTable('pengaturan');
    }
}
