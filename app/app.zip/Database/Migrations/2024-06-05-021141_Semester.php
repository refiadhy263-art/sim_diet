<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Semester extends Migration
{
    public function up()
    {
        // Membuat kolom/field untuk tabel 
        $this->forge->addField([
            'id_semester'          => [
                'type'           => 'INT',
                'constraint'     => 11,
                'auto_increment' => true
            ],
            'nama_semester'       => [
                'type'           => 'VARCHAR',
                'constraint'     => '16'
            ]

        ]);

        // Membuat primary key
        $this->forge->addKey('id_semester', TRUE);

        // Membuat tabel 
        $this->forge->createTable('semester', TRUE);
    }

    //-------------------------------------------------------

    public function down()
    {
        // menghapus tabel 
        $this->forge->dropTable('semester');
    }
}
