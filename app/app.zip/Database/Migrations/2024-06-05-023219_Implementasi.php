<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Implementasi extends Migration
{
    public function up()
    {
        // Membuat kolom/field untuk tabel 
        $this->forge->addField([
            'id_implementasi'          => [
                'type'           => 'INT',
                'constraint'     => 11,
                'auto_increment' => true
            ],
            'id_semester'          => [
                'type'           => 'CHAR',
                'constraint'     => 5,

            ],
            'id_unit'          => [
                'type'           => 'CHAR',
                'constraint'     => 2,

            ],

            'kerjasama'      => [
                'type'           => 'VARCHAR',
                'constraint'     => '225',

            ],
            'judul'      => [
                'type'           => 'VARCHAR',
                'constraint'     => '225',

            ],
            'nomor'      => [
                'type'           => 'VARCHAR',
                'constraint'     => '100',

            ],
            'deskripsi'      => [
                'type'           => 'TEXT',

            ],
            'berkas'      => [
                'type'           => 'VARCHAR',
                'constraint'     => '20',

            ],
            'tahun'      => [
                'type'           => 'CHAR',
                'constraint'     => '4',

            ],
            'created_at DATETIME DEFAULT CURRENT_TIMESTAMP',
            'id_user'      => [
                'type'           => 'CHAR',
                'constraint'     => '3',

            ],



        ]);

        // Membuat primary key
        $this->forge->addKey('id_implementasi', TRUE);

        // Membuat tabel 
        $this->forge->createTable('implementasi', TRUE);
    }

    //-------------------------------------------------------

    public function down()
    {
        // menghapus tabel 
        $this->forge->dropTable('implementasi');
    }
}
